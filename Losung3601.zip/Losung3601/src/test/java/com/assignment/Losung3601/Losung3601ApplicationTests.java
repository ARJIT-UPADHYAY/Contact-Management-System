package com.assignment.Losung3601;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Losung3601ApplicationTests {

	@Test
	void contextLoads() {
	}

}
