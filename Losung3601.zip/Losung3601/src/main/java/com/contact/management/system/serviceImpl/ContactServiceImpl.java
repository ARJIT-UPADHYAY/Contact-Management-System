package com.contact.management.system.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.contact.management.system.entity.Contacts;
import com.contact.management.system.model.ContactsDto;
import com.contact.management.system.repository.ContactRepository;
import com.contact.management.system.response.Response;
import com.contact.management.system.service.ContactService;

@Service("contactService")
public class ContactServiceImpl implements ContactService {

	@Autowired
	ContactRepository contactRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public Response saveContact(ContactsDto contacts) {
		Response resp = new Response();
		try {
			Contacts entity = this.modelMapper.map(contacts, Contacts.class);
			Contacts output = contactRepository.save(entity);

			List<Contacts> list = new ArrayList<>();
			list.add(output);
			resp.setData(list);
			resp.setDescription("Contact Saved successfully");
			resp.setStatus("Success");

		} catch (Exception e) {

			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);

		}
		return resp;
	}

	@Override
	public Response fetchAllContacts() {

		Response resp = new Response();
		try {
			Iterable<Contacts> data = contactRepository.findAll();
			List<Contacts> result = new ArrayList<Contacts>();

			// void java.lang.Iterable.forEach(Consumer<? super Contacts> action)
			// adding data from Iterable data to Collection List
			data.forEach(result::add);

			resp.setData(result);
			resp.setDescription("Fetched data successfully");
			resp.setStatus("Success");

		} catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response updateContact(ContactsDto contacts, Integer contactId) {
		Response resp = new Response();
		List<Contacts> result = new ArrayList<Contacts>();

		try {
			Contacts contDB = contactRepository.findById(contactId).get();

			if (!StringUtils.isEmpty(contacts.getEmail())) {
				contDB.setEmail(contacts.getEmail());

			}
			if (!StringUtils.isEmpty(contacts.getFirstName())) {
				contDB.setEmail(contacts.getFirstName());

			}
			if (!StringUtils.isEmpty(contacts.getLastName())) {
				contDB.setEmail(contacts.getLastName());

			}
			if (!StringUtils.isEmpty(contacts.getPhoneNumber())) {
				contDB.setEmail(contacts.getPhoneNumber());

			}

			Contacts output = contactRepository.save(contDB);
			resp.setStatus("Success");
			resp.setDescription("Contact updated Suceessfully");
			result.add(output);
			resp.setData(result);

		} catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response deleteContact(Integer contactId) {
		Response resp = new Response();

		try {
			contactRepository.deleteById(contactId);
			resp.setStatus("Success");
			resp.setDescription("Contact deleted Suceessfully");
			resp.setData(null);

		} catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response findByFirstName(String firstName) {
		Response resp = new Response();

		try {

			List<Contacts> list = contactRepository.findByFirstName(firstName);
			resp.setStatus("Success");
			resp.setDescription("Fetched by firstname");
			resp.setData(list);

		}

		catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response findByLastName(String lastName) {
		Response resp = new Response();

		try {

			List<Contacts> list = contactRepository.findByLastName(lastName);
			resp.setStatus("Success");
			resp.setDescription("Fetched by lastName");
			resp.setData(list);

		}

		catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response findByEmail(String email) {
		Response resp = new Response();

		try {

			List<Contacts> list = contactRepository.findByEmail(email);
			resp.setStatus("Success");
			resp.setDescription("Fetched by email");
			resp.setData(list);

		}

		catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response findByPhoneNumber(String phoneNumber) {
		Response resp = new Response();

		try {

			List<Contacts> list = contactRepository.findByPhoneNumber(phoneNumber);
			resp.setStatus("Success");
			resp.setDescription("Fetched by phoneNumber");
			resp.setData(list);

		}

		catch (Exception e) {
			resp.setStatus("Failed");
			resp.setDescription(e.getMessage());
			resp.setData(null);
		}
		return resp;
	}

	@Override
	public Response saveListOfContacts(List<ContactsDto> contacts) {
		Response resp = new Response();
		List<Contacts> list = new ArrayList<>();
		Contacts entity = null;

		for (ContactsDto contactObject : contacts) {
			try {
				entity = this.modelMapper.map(contactObject, Contacts.class);
				Contacts output = contactRepository.save(entity);

				list.add(output);
				resp.setData(list);
				resp.setDescription("Contact with FirstName= " + entity.getFirstName() + " Saved successfully");
				resp.setStatus("Success");

			} catch (Exception e) {

				resp.setStatus("Failed to save contact with FirstName =" + contactObject.getFirstName());
				resp.setDescription(e.getMessage());
				list.add(entity);
				resp.setData(list);

			}
		}
		return resp;
	}

	@Override
	public Response updateListOfContacts(List<Contacts> contactslist) {
		Response resp = new Response();
		Contacts contDB = null;
		List<Contacts> result = new ArrayList<Contacts>();
		for (Contacts contacts : contactslist) {
			try {
				contDB = contactRepository.findById(contacts.getId()).get();

				if (!StringUtils.isEmpty(contacts.getEmail())) {
					contDB.setEmail(contacts.getEmail());

				}
				if (!StringUtils.isEmpty(contacts.getFirstName())) {
					contDB.setEmail(contacts.getFirstName());

				}
				if (!StringUtils.isEmpty(contacts.getLastName())) {
					contDB.setEmail(contacts.getLastName());

				}
				if (!StringUtils.isEmpty(contacts.getPhoneNumber())) {
					contDB.setEmail(contacts.getPhoneNumber());

				}

				Contacts output = contactRepository.save(contDB);
				resp.setStatus("Success");
				resp.setDescription("Contact updated Suceessfully for id = " + contacts.getId());
				result.add(output);
				resp.setData(result);

			} catch (Exception e) {
				resp.setStatus("Failed to update for id = " + contacts.getId());
				resp.setDescription(e.getMessage());
				resp.setData(null);
			}
		}
		return resp;
	}

	@Override
	public Response deleteContactByIds(List<Integer> contactIds) {
		Response resp = new Response();
		for (Integer id : contactIds) {
			try {
				contactRepository.deleteById(id);
				resp.setStatus("Success");
				resp.setDescription("Contact deleted Suceessfully for id = " + id);
				resp.setData(null);

			} catch (Exception e) {
				resp.setStatus("Failed to delete for id = " + id);
				resp.setDescription(e.getMessage());
				resp.setData(null);
			}

		}
		return resp;
	}

}
