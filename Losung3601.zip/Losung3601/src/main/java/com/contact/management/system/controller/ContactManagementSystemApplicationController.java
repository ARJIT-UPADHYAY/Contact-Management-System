package com.contact.management.system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.contact.management.system.model.ContactsDto;
import com.contact.management.system.response.Response;
import com.contact.management.system.service.ContactService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/contacts")
public class ContactManagementSystemApplicationController {

	@Autowired
	ContactService contactService;
	
	@PostMapping("/createContact")
	public Response createContact(HttpServletRequest request,@RequestBody ContactsDto contactsDto) {
		Response resp = contactService.saveContact(contactsDto);
		System.out.print("lll");
		return resp;
	}
	
}
